create PACKAGE manager IS
      g_today_date   DATE:= SYSDATE;
      CURSOR lista_USERI IS SELECT ID,EMAIL FROM USERS;
     PROCEDURE adauga_USER (ID USERS.ID%type, EMAIL USER.EMAIL%type);
END manager;
/

