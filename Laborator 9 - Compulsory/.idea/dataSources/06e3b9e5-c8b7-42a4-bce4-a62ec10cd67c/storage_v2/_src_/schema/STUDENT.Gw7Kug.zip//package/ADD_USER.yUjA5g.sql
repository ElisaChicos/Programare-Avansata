create PACKAGE add_user AS
    PROCEDURE addu (ID USERS.ID%type)ș
END add_users;
/

