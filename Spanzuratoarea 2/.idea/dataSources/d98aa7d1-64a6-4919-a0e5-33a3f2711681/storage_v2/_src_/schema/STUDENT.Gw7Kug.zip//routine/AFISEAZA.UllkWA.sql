create PROCEDURE afiseaza AS
   my_age int(2):=5;
BEGIN
   DBMS_OUTPUT.PUT_LINE('Am doar ' || my_age);
END afiseaza;
/

