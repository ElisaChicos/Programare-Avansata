create PACKAGE addus AS
    PROCEDURE addu (uid USERS.ID%type);
END addus;
/

