create PACKAGE BODY addus AS
    PROCEDURE priv AS
    my_string VARCHAR2(20):='Afara este soare';
    BEGIN
     DBMS_OUTPUT.PUT_LINE(my_string);
    END priv;
    PROCEDURE addu(uid USERS.EMAIL%TYPE) IS
        BEGIN
        DBMS_OUTPUT.PUT_LINE('haide');
        END;
    END addu;
    PROCEDURE addu(uid USERS.ID%TYPE) IS
    u_id USERS.EMAIL%TYPE;
    BEGIN
        SELECT EMAIL INTO u_id
        FROM USERS
        WHERE ID=uid;
        dbms_output.put_line('Email: ' || u_id);
    END addu;
END addus;
/

