create FUNCTION afis(id_user USERS.ID%TYPE)
    RETURN BOOLEAN IS 
    v_id NUMBER;
    v_returnValue BOOLEAN;
BEGIN
    SELECT ID INTO v_id FROM USERS WHERE ID = id_user;

    IF v_id >= 1
        v_returnValue = TRUE;
    ELSE v_returnValue = FALSE;

RETURN v_returnValue;
END afis;
/

